//
//  CeldaInstrumentoController.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import Foundation
import UIKit

class CeldaInstrumentoController : UITableViewCell{
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblStock: UILabel!
    @IBOutlet weak var imgInstrumento: UIImageView!
    
}
