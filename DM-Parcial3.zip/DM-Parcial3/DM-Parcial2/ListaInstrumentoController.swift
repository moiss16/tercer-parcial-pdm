//
//  ViewController.swift
//  DM-Parcial2
//
//  Created by David Encinas on 25/10/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return instrumentos.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 245
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaInstrumento") as! CeldaInstrumentoController
        celda.lblNombre.text = instrumentos[indexPath.row].nombre
        celda.lblStock.text = instrumentos[indexPath.row].stock
        celda.imgInstrumento.image = UIImage(named: instrumentos[indexPath.row].imgInstrumento)
        
        return celda
    }
    
    
    var instrumentos : [Instrumento] = []

    @IBOutlet weak var tvInstrumentos: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Instrumentos"
        
        instrumentos.append(Instrumento(nombre: "Guitarra Acustica", stock: "35", imgInstrumento: "guitarra-acustica", marcas: [Marca(nombre: "Yamaha", precio: "$4999", imgMarca: "yamaha-logo"), Marca(nombre: "Fender", precio: "$4999", imgMarca: "fender-logo"), Marca(nombre: "Gibson", precio: "$4999", imgMarca: "gibson-logo"), Marca(nombre: "Takamine", precio: "$4999", imgMarca: "takamine-logo"), Marca(nombre: "Taylor", precio: "$4999", imgMarca: "taylor-logo")]))
        
        instrumentos.append(Instrumento(nombre: "Guitarra Electrica", stock: "21", imgInstrumento: "guitarra-electrica", marcas: [Marca(nombre: "Fender", precio: "$4799", imgMarca: "fender-logo"), Marca(nombre: "Gibson", precio: "$4599", imgMarca: "gibson-logo"), Marca(nombre: "Ibanez", precio: "$3999", imgMarca: "Ibanez-logo"), Marca(nombre: "Paul Reed Smith", precio: "$4999", imgMarca: "paulreedsmith-logo"), Marca(nombre: "Yamaha", precio: "$5999", imgMarca: "yamaha-logo")]))
        
        instrumentos.append(Instrumento(nombre: "Bajo", stock: "20", imgInstrumento: "bajo-electrico", marcas: [Marca(nombre: "Cort", precio: "$3299", imgMarca: "cort-logo"), Marca(nombre: "Feder", precio: "$4599", imgMarca: "fender-logo"), Marca(nombre: "Feder", precio: "$4599", imgMarca: "fender-logo"), Marca(nombre: "Gibson", precio: "$5899", imgMarca: "gibson-logo"), Marca(nombre: "Warwick", precio: "$3799", imgMarca: "warwick-logo"), Marca(nombre: "Yamaha", precio: "$5999", imgMarca: "yamaha-logo")]))
        
        instrumentos.append(Instrumento(nombre: "Ukulele", stock: "13", imgInstrumento: "ukulele", marcas: [Marca(nombre: "Cordoba", precio: "$2799", imgMarca: "cordoba-logo"), Marca(nombre: "Fender", precio: "$2799", imgMarca: "fender-logo"), Marca(nombre: "Kala", precio: "$2799", imgMarca: "kala-logo"), Marca(nombre: "Luna", precio: "$2799", imgMarca: "luna-logo"), Marca(nombre: "Mahalo", precio: "$2799", imgMarca: "mahalo-logo")]))
        
        instrumentos.append(Instrumento(nombre: "Teclado", stock: "10", imgInstrumento: "teclado", marcas: [Marca(nombre: "Casio", precio: "$2999", imgMarca: "casio-logo"), Marca(nombre: "Kawai", precio: "$3999", imgMarca: "kawai-logo"), Marca(nombre: "Korg", precio: "$15999", imgMarca: "korg-logo"), Marca(nombre: "Roland", precio: "$11999", imgMarca: "roland-logo"), Marca(nombre: "Yamaha", precio: "$13999", imgMarca: "yamaha-logo")]))
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToDetalles"{
            let destino = segue.destination as! DetallesIntrumentosController
            let destino2 = segue.destination as! DetallesIntrumentosController
            
            destino.instrumentos = instrumentos[tvInstrumentos.indexPathForSelectedRow!.row]
            destino2.marcas = instrumentos[tvInstrumentos.indexPathForSelectedRow!.row].marcas
            destino.indice = tvInstrumentos.indexPathForSelectedRow!.row
            destino.callBackEliminarContacto = eliminarGuitarra
            
        }
        if segue.identifier == "goToAdd"{
            let destino = segue.destination as! CrearGuitarraController
            destino.callBackAgregarGuitarra = agregarGuitarra
        }
        
    }
    func actualizarTableView(){
        tvInstrumentos.reloadData()
    }
    func agregarGuitarra(instrumento: Instrumento){
        instrumentos.append(instrumento)
        actualizarTableView()
    }
    func eliminarGuitarra(indice: Int){
        instrumentos.remove(at: indice)
        actualizarTableView()
    }
    
    
}

