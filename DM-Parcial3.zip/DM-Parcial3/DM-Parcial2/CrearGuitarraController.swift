//
//  CrearGuitarraController.swift
//  DM-Parcial2
//
//  Created by Jessica Jerez Castro on 24/11/21.
//

import Foundation
import UIKit

class CrearGuitarraController : UIViewController {
    
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtStock: UITextField!
    
    var callBackAgregarGuitarra : ((Instrumento) -> Void)?
    
    
    override func viewDidLoad() {
        self.title = "Crear Guitarra"
    }
    
    @IBAction func doTapGuardar(_ sender: Any) {
        let nuevo = Instrumento(nombre: txtNombre.text!, stock: txtStock.text!, imgInstrumento: "", marcas: [Marca(nombre: "Yamaha", precio: "$4999", imgMarca: "yamaha-logo"), Marca(nombre: "Fender", precio: "$4999", imgMarca: "fender-logo"), Marca(nombre: "Gibson", precio: "$4999", imgMarca: "gibson-logo"), Marca(nombre: "Takamine", precio: "$4999", imgMarca: "takamine-logo"), Marca(nombre: "Taylor", precio: "$4999", imgMarca: "taylor-logo")])
        callBackAgregarGuitarra!(nuevo)
        
        self.navigationController?.popViewController(animated: true)
    }
}
